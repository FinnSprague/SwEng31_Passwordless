import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../AuthForm/AuthForm.css";
import AuthForm from "../AuthForm/AuthForm";
import HomePage from "../HomePage/HomePage";

const SignupPage = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    
    // Load email from sessionStorage
    useEffect(() => {
        const storedEmail = sessionStorage.getItem("userEmail");
        if (storedEmail) setEmail(storedEmail);
    }, []);

    const handleSignup = () => {
        const trimmedEmail = email.trim();
        if (trimmedEmail) {
            sessionStorage.setItem("userEmail", trimmedEmail);
            navigate("/settings", { state: { email: trimmedEmail } });
        }
    };

    return (
        <>
        <HomePage />
            <AuthForm
                title="Sign up"
                primaryButton="Create Account"
                onPrimaryAction={handleSignup}
                secondaryButton="Log in"
                onSecondaryAction={() => navigate("/login")}
                showBottomText={false}
                showTextContainer={false}
                isSignupPage={true}
                email={email}
                setEmail={setEmail}
            />
        </>
    );
};

export default SignupPage;
