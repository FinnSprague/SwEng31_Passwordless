import React, { useState } from "react";
import { Link } from "react-router-dom";
import { format, subDays } from "date-fns";
import DashboardSideBar from "./DashboardSideBar";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "./AppointmentsPage.css";

const AppointmentsPage = () => {
    const [selectedDate, setSelectedDate] = useState(new Date());//updates the day when user picks another day
    const [appointments, setAppointments] = useState([
        { id: 1, patient: "Ethan Carter", time: "10:00", reason: "General Checkup", date: format(new Date(), "dd-MM-yyyy") },
        { id: 2, patient: "Olivia Mitchell", time: "11:30", reason: "Flu Symptoms", date: format(new Date(), "dd-MM-yyyy") }
    ]);
    //stores input to create appointment
    const [newAppointment, setNewAppointment] = useState({ patient: "", time: "", reason: "" });
    //when user inputs it takes the value of the corresponding field (reason, time, patient)
    const handleNewInput = (e) => { setNewAppointment({ ...newAppointment, [e.target.name]: e.target.value }); };
    //if all fields are filled create a new appointment (newEntry) and add it to the list
    const addAppointment = () => {
        if (newAppointment.patient && newAppointment.time && newAppointment.reason) {
            const formattedDate = format(selectedDate, "dd-MM-yyyy");
            const newEntry = {
                id: appointments.length + 1,
                ...newAppointment,
                date: formattedDate,
            };
            setAppointments([...appointments, newEntry]);
            setNewAppointment({ patient: "", time: "", reason: "" });
        } else {
            alert("Please fill in all fields!");
        }
    };
    //filter appointments by date showing only appointments for that day
    const filteredAppointments = appointments.filter((appointment) => appointment.date == format(selectedDate, "dd-MM-yyyy"));

    const [showOptions, setShowOptions] = useState(false);

    return (
        <>
            <DashboardSideBar />
            <Link to="/settings">
                <button className="settings-btn">
                    <img src="images/settingsIcon.svg"></img>
                </button>
            </Link>
            <button className="profile-btn" onClick={() => setShowOptions(!showOptions)}>
                <img src="images/lightProfile.svg"></img>
            </button>
            {showOptions && (
                <div className="profile-btn-options">
                    <Link to="/account" className="item">Manage Account</Link>
                    <Link to="/" className="item">Log Out</Link>
                </div>
            )}

            <div className="appointments-container">
                <h2 className="appointment-title">Appointments</h2>
                <div className="appointments-content">
                    {/* Date Picker + Appointments List*/}
                    <div className="left-section">
                        <div className="datepicker-container">
                            <DatePicker
                                selected={selectedDate}
                                onChange={(date) => setSelectedDate(date)}
                                minDate={subDays(new Date(), 0)}/* no past dates can be selected*/
                                inline /*shows the whole calendar*/
                                calendarClassName="calendar"
                                dayClassName={(date) => format(date, "dd-MM-yyyy") == format(selectedDate, "dd-MM-yyyy") ? "selected-day" : ""}
                            />
                        </div>
                        {/* Appointments List */}
                        <div className="appointments-list-container">
                            <div className="appointments-list">
                                {filteredAppointments.length > 0 ? (
                                    filteredAppointments.map((appointment) => (/*dynamically generates appointment cards*/
                                        <div className="appointment-card">
                                            <p><b>Patient:</b> {appointment.patient}</p>
                                            <p><b>Time:</b> {appointment.time}</p>
                                            <p><b>Reason:</b> {appointment.reason}</p>
                                        </div>
                                    ))) : (<p className="no-appointments">No appointments for this day.</p>)}
                            </div>
                        </div>
                    </div>
                    {/* Add Appointment Form*/}
                    <div className="right-section">
                        <div className="add-appointment-form">
                            <p className="add-appointment-title">Add appointment</p>
                            <input
                                type="text"
                                name="patient"
                                placeholder="Patient Name"
                                value={newAppointment.patient}
                                onChange={handleNewInput}
                            />
                            <input
                                type="time"
                                name="time"
                                value={newAppointment.time}
                                onChange={handleNewInput}
                            />
                            <input
                                type="text"
                                name="reason"
                                placeholder="Reason"
                                value={newAppointment.reason}
                                onChange={handleNewInput}
                            />
                            <button className="add-appointment-btn" onClick={addAppointment}>Add</button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AppointmentsPage;
