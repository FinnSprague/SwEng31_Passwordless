import React, { useState } from "react";
import { Link } from 'react-router-dom';
import "../SettingsPage/SettingsPage.css";
import DashboardSideBar from "./DashboardSideBar";
import "./PatientsPage.css";

const PatientsPage = () => {
    const [patients, setPatients] = useState([
        { id: 1, name: "John Doe", age: 35, gender: "Male", diagnosis: "Flu" },
        { id: 2, name: "Sarah Smith", age: 29, gender: "Female", diagnosis: "Migraine" },
        { id: 3, name: "Michael Brown", age: 42, gender: "Male", diagnosis: "Diabetes" },
        { id: 4, name: "Emily Davis", age: 50, gender: "Female", diagnosis: "Hypertension" },
        { id: 5, name: "James Wilson", age: 60, gender: "Male", diagnosis: "Arthritis" }
    ]);

    const [newPatient, setNewPatient] = useState({
        name: "", age: "", gender: "", diagnosis: ""
    });
    const handleNewInput = (e) => {
        setNewPatient({ ...newPatient, [e.target.name]: e.target.value });
    };
    const addPatient = () => {
        if (newPatient.name && newPatient.age && newPatient.gender && newPatient.diagnosis) {
            setPatients([...patients, { id: patients.length + 1, ...newPatient }]);
            setNewPatient({ name: "", age: "", gender: "", diagnosis: "" });
        } else {
            alert("Please fill in all fields!");
        }
    };

    const [search, setSearch] = useState("");
    const filteredPatients = patients.filter((patient) =>
        patient.name.toLowerCase().includes(search.toLowerCase()));

    const [showOptions, setShowOptions] = useState(false);

    return (
        <>
            <DashboardSideBar />
            <Link to="/settings">
                <button className="settings-btn">
                    <img src="images/settingsIcon.svg"></img>
                </button>
            </Link>
            <button className="profile-btn" onClick={() => setShowOptions(!showOptions)}>
                <img src="images/lightProfile.svg"></img>
            </button>
            {showOptions && (
                <div className="profile-btn-options">
                    <Link to="/account" className="item">Manage Account</Link>
                    <Link to="/" className="item" >Log Out</Link>
                </div>
            )}
            <div className="table-container">
                <h2 className="table-title">Patients</h2>
                <input
                    type="text"
                    className="search-input"
                    placeholder="Search patient"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)} />
                <div className="add-patient-form">
                    <input type="text" name="name" placeholder="Full Name" value={newPatient.name} onChange={handleNewInput} />
                    <input type="number" name="age" placeholder="Age" value={newPatient.age} onChange={handleNewInput} />
                    <select name="gender" value={newPatient.gender} onChange={handleNewInput}>
                        <option value="">Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                    <input type="text" name="diagnosis" placeholder="Diagnosis" value={newPatient.diagnosis} onChange={handleNewInput} />
                    <button className="add-btn" onClick={addPatient}>Add</button>
                </div>
                <div className="patients-table-section">
                    <table className="patients-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Diagnosis</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredPatients.map((patient) => (
                                <tr key={patient.id}>
                                    <td>{patient.id}</td>
                                    <td>{patient.name}</td>
                                    <td>{patient.age}</td>
                                    <td>{patient.gender}</td>
                                    <td>{patient.diagnosis}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
};

export default PatientsPage;
