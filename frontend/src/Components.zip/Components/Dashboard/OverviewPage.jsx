import React, { useState } from "react";
import { Link } from 'react-router-dom';
import DashboardSideBar from "./DashboardSideBar";
import './OverviewPage.css';

const OverviewPage = () => {
    const [showOptions, setShowOptions] = useState(false);

    const appointments = [
        { id: 1, patient: "Liam Bennett", time: "10:00", reason: "General Checkup" },
        { id: 2, patient: "Emma Carter", time: "11:30", reason: "Flu Symptoms" },
        { id: 3, patient: "Noah Thompson", time: "13:00", reason: "Back Pain" },
        { id: 4, patient: "Ava Mitchell", time: "14:30", reason: "Allergy Consultation" },
        { id: 5, patient: "William Scott", time: "16:00", reason: "Headache" },
    ];

    const diagnoses = [
        { id: 1, diagnosis: "Flu", completed: 30 },
        { id: 2, diagnosis: "Back Pain", completed: 15 },
        { id: 3, diagnosis: "General Checkup", completed: 60 },
        { id: 4, diagnosis: "Hypertension", completed: 5 },
        { id: 5, diagnosis: "Headache", completed: 35 },
    ];

    const [currentIndex, setCurrentIndex] = useState(0);
    const nextAppointment = () => { setCurrentIndex((prevIndex) => (prevIndex + 1) % appointments.length); };
    const prevAppointment = () => { setCurrentIndex((prevIndex) => (prevIndex - 1 + appointments.length) % appointments.length); };

    return (
        <>
            <DashboardSideBar />
            <div className="dashboard-content">
                <div className="top-buttons">
                    <Link to="/settings">
                        <button className="settings-btn">
                            <img src="images/settingsIcon.svg" alt="Settings" />
                        </button>
                    </Link>
                    <button className="profile-btn" onClick={() => setShowOptions(!showOptions)}>
                        <img src="images/lightProfile.svg" alt="Profile" />
                    </button>
                    {showOptions && (
                        <div className="profile-btn-options">
                            <Link to="/account" className="item">Manage Account</Link>
                            <Link to="/" className="item">Log Out</Link>
                        </div>
                    )}
                </div>
                <div className="dashboard-cards">
                    <div className="card">
                        <h3>Total Patients</h3>
                        <p>100</p>
                    </div>
                    <div className="card slideshow">
                        <h3>Upcoming Appointments</h3>
                        <div className="appointment-details">
                            <p><b>Patient:</b> {appointments[currentIndex].patient}</p>
                            <p><b>Time:</b> {appointments[currentIndex].time}</p>
                            <p><b>Reason:</b> {appointments[currentIndex].reason}</p>
                        </div>
                        <div className="slideshow-arrows">
                            <button className="arrow-btn" onClick={prevAppointment}>&#x2190;</button>
                            <button className="arrow-btn" onClick={nextAppointment}>&#x2192;</button>
                        </div>
                    </div>
                    <div className="card">
                        <h3>Total Appointments</h3>
                        <p>{appointments.length}</p>
                    </div>
                </div>
                <div className="diagnosis-section">
                    <h3>Confirmed Diagnosis</h3>
                    {diagnoses.map((diagnosis) => (
                        <div className="diagnosis-card">
                            <h4>{diagnosis.diagnosis}</h4>
                            <div className="progress-bar-container">
                                <div className="progress-bar" style={{ width: `${diagnosis.completed}%` }}></div>
                            </div>
                            <p>{diagnosis.completed} diagnoses completed</p>
                        </div>
                    ))}
                </div>
            </div>
        </>
    );
};

export default OverviewPage;
