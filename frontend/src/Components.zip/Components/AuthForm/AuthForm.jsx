import React from "react";
import { Mail } from "lucide-react";
import { Link } from "react-router-dom";
import "./AuthForm.css";

const AuthForm = ({
    title,
    primaryButton,
    onPrimaryAction,
    secondaryButton,
    onSecondaryAction,
    showBottomText,
    showTextContainer,
    isSignupPage,
    email,
    setEmail,
    userType,
    setUserType,
    errorMessage,
}) => {
    return (
        <div className="auth-modal-overlay">
            {showTextContainer && (
                <div className="text-container">
                    <h1>Passwordless <br /> Authentication</h1>
                </div>
            )}
            <div className="auth-container">
                <Link to="/" >
                    <button className="close-btn">
                        <img src="images/lightCloseBar.svg" alt="Close" />
                    </button>
                </Link>

                <h2>{title}</h2>

                <form id="login-form" onSubmit={(e) => {
                    e.preventDefault();
                    onPrimaryAction();
                }}>
                    <label>Enter email:</label>
                    <div className="input-container">
                        <Mail className="input-icon" size={15} />
                        <input
                            type="email"
                            id="email"
                            placeholder="Email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    {/* Show dropdown if signup page */}
                    {isSignupPage && (
                        <div className="dropdown-container">
                            <label>I am a...</label>
                            <select
                                id="userType"
                                value={userType}
                                onChange={(e) => setUserType(e.target.value)}
                                required
                            >
                                <option value="" disabled>Select your role</option>
                                <option value="Doctor">Doctor</option>
                                <option value="Nurse">Nurse</option>
                                <option value="Patient">Patient</option>
                            </select>
                        </div>
                    )}

                    {/* Error Message */}
                    {errorMessage && <p className="error-message">{errorMessage}</p>}

                    <button type="submit" className="primary-btn">{primaryButton}</button>

                    <div className="or-line">
                        <div className="line"></div>
                        <span>Or</span>
                        <div className="line"></div>
                    </div>

                    <button type="button" className="secondary-btn" onClick={onSecondaryAction}>
                        {secondaryButton}
                    </button>

                    {showBottomText && (
                        <p className="alt-text">
                            Don't have an account yet? <Link to="/signup" className="signup-link">Sign Up</Link>
                        </p>
                    )}
                </form>
            </div>
        </div>
    );
};

export default AuthForm;
