import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import { startRegistration } from "@simplewebauthn/browser";
import "./SettingsPage.css";
import SideBar from "./SideBar";
import HomePage from "../HomePage/HomePage"; // Optional layout wrapper

const SettingsPage = () => {
    const location = useLocation();
    const [email, setEmail] = useState("");
    const [creationTime, setCreationTime] = useState(null);
    const [error, setError] = useState("");

    // Load email from sessionStorage or navigation state
    useEffect(() => {
        const storedEmail = sessionStorage.getItem("userEmail");
        const userEmail = location.state?.email || storedEmail || "";
        setEmail(userEmail);

        if (userEmail) {
            fetchPasskeyStatus(userEmail);
        }
    }, [location.state]);

    // Fetch passkey status from backend
    const fetchPasskeyStatus = async (email) => {
        try {
            const response = await fetch(`http://localhost:5000/passkey-status?email=${email}`);
            if (!response.ok) throw new Error("Failed to fetch passkey status");

            const data = await response.json();
            if (data.creationTime) {
                setCreationTime(new Date(data.creationTime).toLocaleString());
            } else {
                setCreationTime(null);
            }
        } catch (error) {
            console.error("Error fetching passkey status:", error);
        }
    };

    const handleEmailChange = (e) => {
        const newEmail = e.target.value;
        setEmail(newEmail);
        sessionStorage.setItem("userEmail", newEmail);
    };

    const register = async () => {
        try {
            const emailTrimmed = email.trim();
            if (!emailTrimmed) {
                setError("Email field is empty");
                return;
            }

            const initResponse = await fetch(`/register?email=${emailTrimmed}`, {
                credentials: "include",
                cache: "no-cache",
            });

            if (!initResponse.ok) throw new Error("Failed to initiate registration");

            const options = await initResponse.json();
            const regJSON = await startRegistration(options);

            const verResponse = await fetch("/verify-reg", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(regJSON),
                credentials: "include",
            });

            const verificationJSON = await verResponse.json();

            if (verificationJSON.verified) {
                fetchPasskeyStatus(emailTrimmed);
                setError("");
            } else {
                throw new Error("Verification failed");
            }
        } catch (error) {
            console.error("Registration Error:", error);
            setError(error.message);
        }
    };

    return (
        <>
        
            <SideBar />
            <div className="account-page">
                <div className="passkey-section">
                    <h3>
                        <img src="images/key.svg" alt="key icon" /> Passkey
                    </h3>
                    <div className="passkey-info">
                        <div className="passkey-btns">
                            <button className="create-passkey-btn" onClick={register}>
                                Create passkey
                            </button>
                            <button className="delete-passkey-btn">Delete passkey</button>
                        </div>
                        {error && <p className="error-message">{error}</p>}
                        <table className="passkey-table">
                            <thead>
                                <tr>
                                    <th>Created</th>
                                    <th>Last Used</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{creationTime || "Not created yet"}</td>
                                    <td>17/02/2025 15:50</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div className="email-section">
                    <h3>
                        <img src="images/mail.svg" alt="mail icon" /> Email
                    </h3>
                    <input
                        type="email"
                        value={email}
                        onChange={handleEmailChange}
                        placeholder="Enter your email"
                    />
                    <p>Current email: {email || "No email provided"}</p>
                </div>

                <button className="delete-account-btn">Delete account</button>
            </div>
       </>
    );
};

export default SettingsPage;
