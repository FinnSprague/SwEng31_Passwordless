import React from "react";
import { Link, useLocation} from "react-router-dom";
import "./SettingsPage.css";
import "../HomePage/HomePage.css";

const SideBar = () => {//nome da cambiare pk non rappresenta piu una barra laterale
    const location = useLocation();
    return (
        <>
            <header className="account-header">
                <div className="logo-container">
                    <img src="images/logo.svg" className="logo-img" />
                    <div className="logo-text-scrolled">Hosportal</div>
                    <Link to="/overview"><button className="account-home-btn">Home</button></Link>
                </div>
                {location.pathname === "/settings" ? (
                    <Link to="/account">
                        <button className="account-settings-btn">
                            <img src="images/logInIcon.svg" alt="Account" />
                        </button>
                    </Link>
                ) : (
                    <Link to="/settings">
                        <button className="account-settings-btn">
                            <img src="images/settingsIcon.svg" alt="Settings" />
                        </button>
                    </Link>
                )}
                <Link to="/">
                    <button className="account-logout-btn">Log out
                        <img src="images/lightLogOutIcon.svg"></img>
                    </button>
                </Link>
            </header>
        </>
    );
};

export default SideBar;
