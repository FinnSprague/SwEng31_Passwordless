import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import "./SettingsPage.css";
import SideBar from "./SideBar";

const AccountPage = () => {
    const location = useLocation();
    const userEmail = location.state?.email || "No email provided";
    const userRole = location.state?.userType || "No role provided";

    const [isEditing, setIsEditing] = useState(false);
    const [fullName, setFullName] = useState("Name Surname");
    const [dob, setDob] = useState("dd/mm/yyyy");
    const [phoneNum, setPhoneNum] = useState("phone number");
    const [profileImage, setProfileImage] = useState("images/profile.svg");

    const handleEditClick = () => {
        setIsEditing(!isEditing);
    };

    const handleImageChange = (e) => {
        const file = e.target.files[0];//takes first file selected
        if (file) {
            //if a file is selected, generates a temporary url and updates state of profileImage
            setProfileImage(URL.createObjectURL(file));
        }
    };

    return (
        <>
            <SideBar />
            <div className="account-page">
                <div className="account-section">
                    <div className="title-line">
                        <h3>My Account</h3>
                        <button className="edit-btn" onClick={handleEditClick}>{isEditing ? "Save" : "Edit"}</button>
                    </div>
                    <div className="profile-and-info">
                        <img className="profile-img" src={profileImage}></img>
                        <button className="editProfile-btn" >
                            <label htmlFor="ImageInput">
                                <img src="images/editProfileButton.svg"></img>
                            </label>
                        </button>
                        <input
                            type="file"
                            id="ImageInput"
                            accept="image/*"
                            style={{ display: "none" }}
                            onChange={handleImageChange}
                        />
                        <div className="personal-info">
                            <span>
                                <label>Full Name</label>
                                {isEditing ? (
                                    <input
                                        className="editable-input"
                                        type="text"
                                        value={fullName}
                                        onChange={(e) => setFullName(e.target.value)} />
                                ) : (
                                    <p>{fullName}</p>)}
                            </span>
                            <span>
                                <label>Role</label>
                                <p>{userRole}</p>
                            </span>
                            <span>
                                <label>Date of Birth</label>
                                {isEditing ? (
                                    <input
                                        className="editable-input"
                                        type="date"
                                        value={dob}
                                        onChange={(e) => setDob(e.target.value)} />
                                ) : (
                                    <p>{dob}</p>)}
                            </span>
                            <span>
                                <label>Email address</label>
                                <p>{userEmail}</p>
                            </span>
                            <span>
                                <label>Phone number</label>
                                {isEditing ? (
                                    <input
                                        className="editable-input"
                                        type="tel"
                                        value={phoneNum}
                                        onChange={(e) => setPhoneNum(e.target.value)} />
                                ) : (
                                    <p>{phoneNum}</p>)}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default AccountPage;
